#include <stdio.h>
#include <stdlib.h>
#include "rmar0.h"

// stubs for Hil functions
#ifdef __cplusplus
extern "C" {
#endif
void __Hil__Static_Init_Func__(void) {} 
#ifdef __cplusplus
}
#endif

